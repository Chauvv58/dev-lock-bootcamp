# Session 01 - Giới thiệu Blockchain và cài môi trường

- **GitHub:** @student-demo
- **Ngày học:** 2026-11-10
- **Thời lượng:** 3 giờ

## 1. Hôm nay mình học được gì
- Blockchain là sổ cái phân tán: mỗi block chứa hash của block trước nên khó sửa dữ liệu cũ.
- Phân biệt ví (wallet), địa chỉ (address) và khóa riêng (private key).
- Giao dịch cần được ký bằng private key và được mạng lưới xác nhận.

## 2. Mình đã làm gì (thực hành)
- Cài Git, Node.js và tạo ví testnet.
- Nhận token testnet từ faucet và gửi thử một giao dịch.
- Tạo repo `dev-lock-bootcamp` và push devlog đầu tiên.

## 3. Khó khăn và cách xử lý
- Faucet báo lỗi rate limit, nên mình đợi 1 giờ rồi thử lại.
- `git push` bị từ chối vì chưa đổi remote, nên mình chạy `git remote set-url origin ...`.

## 4. Evidence (bằng chứng)
- Link: https://github.com/student-demo/dev-lock-bootcamp/commit/abc1234
- Ảnh: ảnh chụp giao dịch testnet (đặt trong `docs/assets/`)

## 5. Câu hỏi còn lại / việc cần làm tiếp
- Consensus (PoW và PoS) khác nhau cụ thể thế nào?

## Checklist trước khi commit
- [x] Đã điền đủ các mục trên
- [x] Evidence mở được bằng link hoặc ảnh
- [x] Không chứa private key, seed phrase, password, API key
- [x] Commit theo mẫu `[S01] add devlog - @student-demo`
