#!/usr/bin/env python3
"""Kiểm tra một file devlog: đủ mục chưa, có evidence chưa, có lộ bí mật không.

Dùng: python3 scripts/check_devlog.py submissions/<username>/session-01.md
"""
import re
import sys
from pathlib import Path

REQUIRED_SECTIONS = [
    "Hôm nay mình học được gì",
    "Mình đã làm gì",
    "Khó khăn và cách xử lý",
    "Evidence",
]

SECRET_PATTERNS = {
    "private key (0x + 64 ký tự hex)": re.compile(r"\b0x[a-fA-F0-9]{64}\b"),
    "PEM private key": re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
    "seed phrase (từ khóa seed/mnemonic kèm 12+ từ)": re.compile(
        r"(?i)(seed|mnemonic)[^\n]{0,20}[:=]\s*(?:[a-z]+\s+){11,}[a-z]+"
    ),
    "API key kiểu sk-...": re.compile(r"\bsk-[A-Za-z0-9]{20,}\b"),
    "GitHub token": re.compile(r"\bgh[pousr]_[A-Za-z0-9]{30,}\b"),
    "password/secret gán trực tiếp": re.compile(
        r"(?i)\b(password|passwd|secret|api[_-]?key)\s*[:=]\s*\S{6,}"
    ),
}


def section_body(text: str, title: str) -> str:
    """Lấy nội dung của mục '## ... title ...' tới mục kế tiếp."""
    pattern = re.compile(
        rf"^##\s+[^\n]*{re.escape(title)}[^\n]*\n(.*?)(?=^##\s|\Z)",
        re.S | re.M | re.I,
    )
    m = pattern.search(text)
    return m.group(1) if m else ""


def strip_comments(s: str) -> str:
    return re.sub(r"<!--.*?-->", "", s, flags=re.S)


def check(path: Path) -> int:
    text = path.read_text(encoding="utf-8")
    errors, warnings = [], []

    for title in REQUIRED_SECTIONS:
        body = strip_comments(section_body(text, title)).strip()
        # bỏ các dòng chỉ có dấu gạch đầu dòng trống
        meaningful = [
            ln for ln in body.splitlines()
            if re.sub(r"[-*\s]|Link:|Ảnh:", "", ln)
        ]
        if not body:
            errors.append(f"Thiếu mục: '{title}'")
        elif not meaningful:
            errors.append(f"Mục '{title}' chưa điền nội dung")

    evidence = strip_comments(section_body(text, "Evidence"))
    if not re.search(r"https?://\S+|!\[[^\]]*\]\([^)]+\)", evidence):
        errors.append("Evidence cần ít nhất một link http(s) hoặc một ảnh")

    for name, pat in SECRET_PATTERNS.items():
        if pat.search(text):
            errors.append(f"Nghi ngờ lộ bí mật: {name}")

    if "- [ ]" in text:
        warnings.append("Checklist cuối file vẫn còn mục chưa tick")

    for w in warnings:
        print(f"[CẢNH BÁO] {w}")
    for e in errors:
        print(f"[LỖI] {e}")
    if errors:
        print(f"\n❌ {path}: {len(errors)} lỗi, hãy sửa trước khi commit.")
        return 1
    print(f"✅ {path}: devlog hợp lệ.")
    return 0


def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    code = 0
    for arg in sys.argv[1:]:
        p = Path(arg)
        if not p.is_file():
            print(f"[LỖI] Không tìm thấy file: {arg}")
            code = 1
            continue
        code = max(code, check(p))
    return code


if __name__ == "__main__":
    sys.exit(main())
