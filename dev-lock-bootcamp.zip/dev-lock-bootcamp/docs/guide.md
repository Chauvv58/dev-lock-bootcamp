# Hướng dẫn chi tiết

## Devlog là gì?
Devlog là nhật ký ngắn sau mỗi buổi học: bạn học gì, làm gì, gặp lỗi gì và có bằng chứng gì. Viết ngay sau buổi học sẽ dễ nhớ hơn nhiều so với viết dồn cuối kỳ.

## Quy trình mỗi buổi
1. Copy `templates/session-devlog.md` thành `submissions/<username>/session-XX.md`.
2. Điền các mục, ưu tiên viết bằng lời của mình.
3. Gắn evidence: link commit, link repo, ảnh chụp màn hình.
4. Chạy `python3 scripts/check_devlog.py <file>` để kiểm tra.
5. Commit và push.

## Evidence tốt trông như thế nào?
- Link commit hoặc PR mở được khi chưa đăng nhập.
- Ảnh chụp màn hình thấy rõ kết quả, ngày giờ hoặc mã giao dịch.
- Tránh ảnh che hết thông tin hoặc link yêu cầu quyền riêng tư.

## Bảo mật
- Không commit private key, seed phrase, password, API key.
- `.gitignore` đã chặn file `.env` và các file khóa phổ biến, nhưng vẫn hãy tự kiểm tra trước khi push.
- Nếu lỡ lộ khóa: thu hồi hoặc tạo khóa mới ngay lập tức.

## Mẹo
- Mỗi buổi một commit, message đúng mẫu để dễ tra lịch sử.
- Đặt ảnh vào `docs/assets/` và dùng đường dẫn tương đối.
