# Dev Lock - Bootcamp

Repo mẫu để mình tự theo dõi quá trình học: viết devlog sau mỗi buổi, commit đều đặn và lưu evidence (bằng chứng) có thể kiểm tra được.

## Cách dùng

1. Tạo một repo riêng trên GitHub (ví dụ `dev-lock-bootcamp`).
2. Clone repo này về máy và đổi remote sang repo của bạn:
   ```bash
   git clone <link-repo-nay>
   cd dev-lock-bootcamp
   git remote set-url origin https://github.com/<username>/<ten-repo>.git
   ```
3. Copy `templates/session-devlog.md` thành `submissions/<github-username>/session-XX.md` (XX = 01, 02, ...).
4. Điền nội dung và gắn link/ảnh evidence.
5. Kiểm tra devlog trước khi commit:
   ```bash
   python3 scripts/check_devlog.py submissions/<github-username>/session-01.md
   ```
6. Commit theo mẫu: `[S01] add devlog - @github-username`
7. Push: `git push -u origin main`

Nên nộp/hoàn thành trước buổi học kế tiếp ít nhất 1 ngày.

## Cấu trúc

```
dev-lock-bootcamp/
├── docs/                  # Hướng dẫn chi tiết
│   └── guide.md
├── examples/
│   └── student-demo/      # Devlog mẫu đã điền sẵn
├── scripts/
│   └── check_devlog.py    # Kiểm tra devlog: đủ mục chưa, có lộ bí mật không
├── submissions/           # Devlog của bạn: submissions/<username>/session-XX.md
├── templates/
│   └── session-devlog.md  # Mẫu devlog
├── .gitignore
└── README.md
```

## Quy ước commit

| Việc | Mẫu commit |
| --- | --- |
| Thêm devlog | `[S01] add devlog - @username` |
| Sửa devlog | `[S01] update devlog - @username` |
| Thêm evidence | `[S01] add evidence - @username` |

## Lưu ý

- Evidence phải là link hoặc ảnh mà người khác kiểm tra được.
- Không commit private key, seed phrase, password hoặc API key. Nếu lỡ commit, hãy đổi/thu hồi key ngay, vì xóa commit cũ là chưa đủ.

Xem `examples/student-demo` để làm theo.
