# Session XX - <Tên buổi học>

- **GitHub:** @your-github-username
- **Ngày học:** YYYY-MM-DD
- **Thời lượng:** X giờ

## 1. Hôm nay mình học được gì
<!-- 3-5 ý chính, viết bằng lời của mình -->
-
-
-

## 2. Mình đã làm gì (thực hành)
<!-- Lệnh đã chạy, code đã viết, thứ đã dựng -->
-

## 3. Khó khăn và cách xử lý
<!-- Lỗi gặp phải, cách debug, nguồn tham khảo -->
-

## 4. Evidence (bằng chứng)
<!-- Link hoặc ảnh có thể kiểm tra: commit, PR, repo, ảnh chụp màn hình, link giao dịch... -->
- Link:
- Ảnh: ![mô tả](../../docs/assets/ten-anh.png)

## 5. Câu hỏi còn lại / việc cần làm tiếp
-

## Checklist trước khi commit
- [ ] Đã điền đủ các mục trên
- [ ] Evidence mở được bằng link hoặc ảnh
- [ ] Không chứa private key, seed phrase, password, API key
- [ ] Commit theo mẫu `[SXX] add devlog - @username`
